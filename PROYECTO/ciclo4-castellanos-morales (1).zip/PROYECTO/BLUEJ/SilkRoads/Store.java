package SilkRoads;

public class Store extends StoreBase {

    public Store(int position, int tenges) {
        super("normal", position, tenges);
    }

}
